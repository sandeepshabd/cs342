from .player import Team
